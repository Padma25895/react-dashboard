import './App.css';
import Dashboard from './Components/Dashboard';

function App() {
  return (
    <div class="container-scroller">
      <Dashboard/>
    </div>
  );
}

export default App;
